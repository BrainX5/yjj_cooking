using UnityEngine;

public class SCUT_OpeningUI : MonoBehaviour
{
    public GameObject uiPanel; // 你的UI界面物体
    public SCUT_PlayerMushroom playerMushroomScript; // 拖入挂载了采蘑菇脚本的物体

    private bool uiClosed = false;

    void Update()
    {
        if (!uiClosed && Input.GetKeyDown(KeyCode.Space))
        {
            uiClosed = true;
            
            // 1. 隐藏UI
            if (uiPanel != null) uiPanel.SetActive(false);
            
            // 2. 🔥 核心：激活采蘑菇的空格监听！
            if (playerMushroomScript != null)
            {
                playerMushroomScript.StartGame();
            }
            
            Debug.Log("【UI关闭】第一下空格触发成功。");
        }
    }
}
