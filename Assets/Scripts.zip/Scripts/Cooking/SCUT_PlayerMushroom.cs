using UnityEngine;

public class SCUT_PlayerMushroom : MonoBehaviour
{
    public int count = 0;
    public KeyCode pickupKey = KeyCode.Space;
    
    private bool isGameStarted = false; // 游戏是否正式开始
    private bool isLevelTriggered = false; // 状态锁，防止单帧多次广播

    // 📢 提供给 UI 脚本调用的接口：正式开始游戏
    public void StartGame()
    {
        isGameStarted = true;
        count = 0; // 确保计数从0开始
        Debug.Log("【游戏正式开始】采蘑菇脚本激活，现在开始按空格会计算数量。");
    }

    void Update()
    {
        // 1. 如果游戏还没正式开始，或者已经触发了精灵，直接无视空格
        if (!isGameStarted || isLevelTriggered) return;

        if (Input.GetKeyDown(pickupKey))
        {
            count++;
            Debug.Log("Mushroom Picked! Count: " + count + "/5");

            if (count >= 5)
            {
                isLevelTriggered = true; 
                TriggerImpLevel();
            }
        }
    }

    private void TriggerImpLevel()
    {
        GameObject[] allObjects = GameObject.FindObjectsOfType<GameObject>();
        foreach (GameObject go in allObjects)
        {
            if (go.activeInHierarchy)
            {
                go.SendMessage("TriggerImpAttack", SendMessageOptions.DontRequireReceiver);
            }
        }
    }
}