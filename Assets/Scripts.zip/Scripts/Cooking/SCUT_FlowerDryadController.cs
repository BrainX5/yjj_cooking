﻿using UnityEngine;
using System.Collections;

public class SCUT_FlowerDryadController : MonoBehaviour
{
    public enum ImpPhase { Waiting, Appears, Weightless, Recovered }
    [Header("[Imp State Matrix]")]
    public ImpPhase currentPhase = ImpPhase.Waiting;

    [Header("[BCI Data Core]")]
    [Range(0, 100)] public float focusScore = 0f;
    public float targetFocus = 75f;
    public float requiredDuration = 2.5f;

    [Header("[VFX Core Box]")]
    public ParticleSystem windParticle;

    [Header("[Fly Distance Config]")]
    public float stopDistanceToCamera = 3f;
    public float flySpeed = 15f;

    public GameObject floatingObjects;
    public GameObject flowerDryadObject;
    public AudioSource windAudio;

    private bool waitingForSpace = false;
    private float focusTimer = 0f;
    private Animator impAnimator;
    private Renderer[] impRenderers;
    private Transform mainCameraTransform;

    void Awake()
    {
        impAnimator = GetComponent<Animator>();
        impRenderers = GetComponentsInChildren<Renderer>();
    }

    void Start()
    {
        if (Camera.main != null) mainCameraTransform = Camera.main.transform;

        SetImpVisibility(false);
        if (flowerDryadObject != null) flowerDryadObject.SetActive(false);
        if (windParticle != null) windParticle.Stop();
        
        // 🔥 【强行静音】开局无论如何都不准响
        if (windAudio != null)
        {
            windAudio.Stop();
            windAudio.loop = true; // 确保风声是循环播放的
        } 
    }

    void Update()
    {
        if (currentPhase == ImpPhase.Weightless)
        {
            HandleFocusTraining();
        }
        
        // 只有当精灵飞到到位后，才允许按下最后一下空格
        if (waitingForSpace && Input.GetKeyDown(KeyCode.Space))
        {
            StartWeightlessMode();
        }
    }

    void TriggerImpAttack()
    {
        if (currentPhase != ImpPhase.Waiting) return; 
        
        Debug.Log("【事件触发】5个蘑菇集齐！精灵开始出场。此时风声绝不会响。");
        currentPhase = ImpPhase.Appears;

        if (flowerDryadObject != null) flowerDryadObject.SetActive(true);

        waitingForSpace = false; // 严防死守，此时不接收空格
        StartCoroutine(ImpEntranceAndFlySequence());
    }

    IEnumerator ImpEntranceAndFlySequence()
    {
        if (windParticle != null) windParticle.Play();
        yield return new WaitForSeconds(0.6f);

        SetImpVisibility(true);
        if (impAnimator != null) impAnimator.SetTrigger("Attack");

        if (mainCameraTransform != null)
        {
            Vector3 targetPosition = mainCameraTransform.position + (mainCameraTransform.forward * stopDistanceToCamera);
            targetPosition.y = mainCameraTransform.position.y - 0.5f;

            // 飞向相机
            while (Vector3.Distance(transform.position, targetPosition) > 0.2f)
            {
                Vector3 lookPos = mainCameraTransform.position - transform.position;
                lookPos.y = 0;
                if (lookPos != Vector3.zero) transform.rotation = Quaternion.LookRotation(lookPos);

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, flySpeed * Time.deltaTime);
                yield return null;
            }
            transform.position = targetPosition;
        }

        // 🔥 【精准放行】等精灵完全停在玩家眼前了，再等待下一发空格
        Debug.Log("【阶段就绪】精灵已就位！请按最后一次 [Space] 开启失重和风声！");
        
        yield return new WaitForSeconds(0.1f); // 稍微缓冲0.1秒，防止上一帧的按键粘连
        waitingForSpace = true; 
    }

    void StartWeightlessMode()
    {
        waitingForSpace = false;
        currentPhase = ImpPhase.Weightless;
        Debug.Log("【失重模式启动】风声响起，蘑菇起飞！");

        // 此时才播放风声！
        if (windAudio != null) windAudio.Play();

        // 蘑菇起飞
        if (floatingObjects != null)
        {
            floatingObjects.SetActive(true);
            WeightlessFloat[] allFloatObjects = floatingObjects.GetComponentsInChildren<WeightlessFloat>();
            
            Debug.Log($"找到的蘑菇脚本数量: {allFloatObjects.Length}");
            foreach (WeightlessFloat wf in allFloatObjects)
            {
                wf.StartFloating();
            }
        }
    }

    // 后续 HandleFocusTraining 和 WinSequence 保持不变...
    void HandleFocusTraining()
    {
        if (mainCameraTransform != null)
        {
            Vector3 lookPos = mainCameraTransform.position - transform.position;
            lookPos.y = 0;
            if (lookPos != Vector3.zero) transform.rotation = Quaternion.LookRotation(lookPos);
        }

        if (focusScore >= targetFocus)
        {
            focusTimer += Time.deltaTime;
            if (focusTimer >= requiredDuration)
            {
                currentPhase = ImpPhase.Recovered;
                StartCoroutine(WinSequence());
            }
        }
        else
        {
            focusTimer = Mathf.Max(0f, focusTimer - Time.deltaTime);
        }
    }

    IEnumerator WinSequence()
    {
        if (impAnimator != null) impAnimator.SetTrigger("Idle");
        if (windParticle != null) windParticle.Stop();
        SetImpVisibility(false);
        if (windAudio != null) windAudio.Stop();

        yield return new WaitForSeconds(1.0f);
        currentPhase = ImpPhase.Waiting;
    }

    void SetImpVisibility(bool isVisible)
    {
        foreach (Renderer rend in impRenderers)
        {
            if (rend != null) rend.enabled = isVisible;
        }
    }
}